﻿using System;
using System.Runtime.InteropServices;

namespace Interop.Excel {

    [Guid("00024500-0000-0000-C000-000000000046"), ComImport, TypeLibType(2), ClassInterface((short)0)]
    class Excel { }

}

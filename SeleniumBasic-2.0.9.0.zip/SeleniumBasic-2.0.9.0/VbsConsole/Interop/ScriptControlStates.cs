﻿
namespace Interop.MSScript {

    public enum ScriptControlStates {
        Initialized = 0,
        Connected = 1
    }

}
